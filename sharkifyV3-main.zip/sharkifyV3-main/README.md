# sharkifyV3
🦈⚙️
-**this is a hood legends roblox script GUI that is open source**
-**you can dm the maker on discord: shark!#0001**


- will i ever stop updating the **GUI?** most likely no. i have added many things in this gui that makes it very good so i might stop updating until the game gets a better **BETTER ANTI-CHEAT**.


- also sorry how the updates are confusing i do that so if i ever remove something that somebody liked then they have access to it.

-  feel free to edit the gui. its open source for a reason 


- loadstring(game:HttpGet("https://raw.githubusercontent.com/sharkifyy/sharkifyV3/main/2.3", true))() -- most recent update

- loadstring(game:HttpGet("https://raw.githubusercontent.com/sharkifyy/sharkifyV3/main/2.2", true))() -- 2.2 update 

- loadstring(game:HttpGet("https://raw.githubusercontent.com/sharkifyy/sharkifyV3/main/2.1", true))() -- 2.1 update

- loadstring(game:HttpGet("https://raw.githubusercontent.com/sharkifyy/sharkifyV3/main/2.0", true))() -- oldest 
